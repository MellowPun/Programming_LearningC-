﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Opgave1
{
    internal class Program
    {
        // This is the exam made by Hannah-Marie Hermans
        static void Main(string[] args)
        {
            Console.Write("Geef je verjaardag in als volgt: dd-mm:\n(Dus bijvoorbeeld 22-10 voor 22 oktober)\n");
            string birthday = Console.ReadLine();

            Console.WriteLine();

            // opgave1
            string day = birthday.Substring(0, birthday.IndexOf("-"));
            bool parseSucceeded = int.TryParse(day, out int dayInt);
            string month = birthday.Substring(birthday.IndexOf("-") + 1);
            int.TryParse(month, out int monthInt);

            if(parseSucceeded)
            {
                Console.WriteLine("1 Dit is je verjaardag volgens mm-dd: {0}-{1}.", monthInt, dayInt);
            }
            else
            {
                Console.WriteLine("0 Ongeldige dag opgegeven: {0}", dayInt);
            }

            Console.WriteLine();
            // opgave 2 en 3
            switch (monthInt)
            {
                case 1:
                    month = "januari";
                    break;
                case 2:
                    month = "februari";
                    break;
                case 3:
                    month = "maart";
                    break;
                case 4:
                    month = "april";
                    break;
                case 5:
                    month = "mei";
                    break;
                case 6:
                    month = "juni";
                    break;
                case 7:
                    month = "juli";
                    break;
                case 8:
                    month = "augustus";
                    break;
                case 9:
                    month = "september";
                    break;
                case 10:
                    month = "oktober";
                    break;
                case 11:
                    month = "november";
                    break;
                case 12:
                    month = "december";
                    break;
                default:
                    month = "invalid";
                    break;
            }

            if(month != "invalid")
            {
                Console.WriteLine("2 Dit is je verjaardag volgens dd-mmmm: {0}-{1}.", dayInt, month);
            }
            else
            {
                Console.WriteLine("3 Ongeldige maand opgegeven: {0}.", month);
            }

            Console.WriteLine();
            // opgave4
            double pow;
            pow = Math.Pow(dayInt, monthInt);
            Console.WriteLine("4 De dag tot de macht maand: {0}.", pow);

            Console.WriteLine();
            // opgave5
            int days;
            if(monthInt == 1 || monthInt == 3 || monthInt == 5 || monthInt == 7 || monthInt == 8 || monthInt == 10 || monthInt == 12)
            {
                days = 31;
            }
            else if(monthInt == 4 || monthInt == 6 || monthInt == 9 || monthInt == 11)
            {
                days = 30;
            }
            else if(monthInt == 2)
            {
                days = 28;
            }
            else
            {
                days = -1;
            }

            Console.WriteLine("5 Er zijn {0} dagen in de maand van je verjaardag. ", days);
            Console.WriteLine();

            // opgave6
            int shift = -10;
            int i = 0; 
            int amountToDeduct = 97; // lowercase 
            char myChar;
            int charInt;
            Console.Write("6 Dit is je maand: ");
            do
            {
                myChar = month.ElementAt(i);   // numerieke waarden ascii dus voor oktober 'o - 111'
                charInt = (int)myChar;          // ascii waarden opzetten naar int dus 111 char wordt 111 int

                charInt = charInt + shift;          // verschuiving 
                charInt = charInt - amountToDeduct;  // a op 0 zetten dus 'o - 111' wordt 'o - 15'

                charInt = charInt % 26;         // checken voor overflow: z moet tellen naar a
                if (charInt < 0)
                {
                    charInt = 26 + charInt;
                }

                charInt = charInt + amountToDeduct;     // terugzetten naar oorspronkelijke waarde ascii 
                char letter = (char)charInt;

                Console.Write(letter);
                

                i++;
            } while (i <= 1);

            Console.WriteLine(month.Substring(2));
            Console.WriteLine("maar de eerste 2 letters ervan zijn verschoven. ");
           

            Console.ReadLine();
        }




        /* OPGAVE 6 VOOR EEN LETTER
        int shift = -10;
            int amountToDeduct = 97; // lowercase 

            char myChar = month.ElementAt(0);   // numerieke waarden ascii dus voor oktober 'o - 111'
            int charInt = (int)myChar;          // ascii waarden opzetten naar int dus 111 char wordt 111 int

            charInt = charInt + shift;          // verschuiving 
            charInt = charInt - amountToDeduct;  // a op 0 zetten dus 'o - 111' wordt 'o - 15'

            charInt = charInt % 26;         // checken voor overflow: z moet tellen naar a
            if (charInt < 0)
            {
                charInt = 26 + charInt;
            }

            charInt = charInt + amountToDeduct;     // terugzetten naar oorspronkelijke waarde ascii 
            Console.WriteLine("6 Dit is je maand: {0},\nmaar de eerste 2 letters ervan zijn verschoven.", (char)charInt);
        */
    }
}
