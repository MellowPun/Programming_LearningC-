﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave1
{
    internal class Program
    {
        // This is the exam made by Hannah-Marie Hermans
        static void Main(string[] args)
        {
            int inputNr;
            bool parseSucceeded;
            do
            {
                Console.Write("Enter an integer number: ");
                parseSucceeded = int.TryParse(Console.ReadLine(), out inputNr);
            } while (!parseSucceeded);

            double sqrt = 0.2; // vijdemacht = x tot de 1/5   ==> 1/5 = 0.2 

            Console.WriteLine(Math.Round(Math.Pow(inputNr, sqrt),2));

            Console.ReadKey();
        }
    }
}
