﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave2
{
    internal class Program
    {
        // This is the exam made by Hannah-Marie Hermans
        static void Main(string[] args)
        {
            // dit is eigenlijk niet de juiste manier, want dit hebben we nog niet gezien in de lessen 
            // weet niet hoe het anders moet 
            
            string inputString;

            Console.Write("Write a sentence: ");
            inputString = Console.ReadLine();

            string[] words = inputString.Split(' ');


            int x = 0;
            int col;
            while (x < words.Length)
            {
                col = 1;
                while (col <= x)
                {
                    Console.Write("-");  // '-' stellen spaties voor, maar op te checken of het werkt, gebruik ik dit
                    col++;
                }
                string word = words[x];
                Console.Write(word);
                x++;
            }

            Console.ReadKey();
        }
    }
}
