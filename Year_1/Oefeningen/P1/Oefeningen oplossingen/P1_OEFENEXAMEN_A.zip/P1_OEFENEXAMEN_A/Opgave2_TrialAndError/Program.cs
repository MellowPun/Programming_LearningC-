﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave2_TrialAndError
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // dit is trial and error versie en dus niet goed 
            int wordLength;
            int row = 1;
            int col;
            int cols;
            string words;
            string sentence = "hello im hm";


            words = sentence.Substring(0, sentence.IndexOf(" "));
            wordLength = words.Length;
            Console.WriteLine(words);

            sentence = sentence.Substring(sentence.IndexOf(" ") + 1);
            words = sentence.Substring(0, sentence.IndexOf(" "));
            wordLength = words.Length;
            Console.WriteLine(words);

            sentence = sentence.Substring(sentence.IndexOf(" ") + 1);
            words = sentence.Substring(0);
            wordLength = words.Length;
            Console.WriteLine(words);


            while (row <= wordLength)
            {
                col = wordLength;
                while (col <= wordLength)
                {
                    Console.Write(words);
                    col++;
                }
                cols = 1;
                while (cols <= row)
                {
                    Console.Write("-");
                    cols++;
                }
                row++;
            }



            Console.ReadKey();
        }
    }
}
