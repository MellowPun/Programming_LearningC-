﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AAdll
{// This exam is made by Achoukhi Ayoub
    public interface IShowable
    {
        void Show();
        bool IsDigital();

    }
}
